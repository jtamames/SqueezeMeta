#' Hadza hunter-gatherer gut metagenomes
#'
#' Subset of 5 bins (and the associated contigs and genes)
#' obtained from running SqueezeMeta on two gut metagenomic samples
#' obtained from two hunter-gatherers of the Hadza ethnic group.
#'
#' @docType data
#'
#' @usage data(Hadza)
#'
#' @format A SQM object; see \code{\link[loadSQM]{loadSQM}}.
#'
#' @keywords datasets
#'
#' @references Rampelli \emph{et al.}, 2015. Metagenome Sequencing of the Hadza
#' Hunter-Gatherer Gut Microbiota. \emph{Curr. biol.} \bold{25}:1682-93
#' (\href{://www.ncbi.nlm.nih.gov/pubmed/25981789}{PubMed}).
#'
#' @source \href{https://www.ncbi.nlm.nih.gov/sra/?term=SRR1927149}{SRR1927149}, \href{https://www.ncbi.nlm.nih.gov/sra/?term=SRR1929485}{SRR1929485}.
#'
#' @examples
#' data(Hadza)
#' plotTaxonomy(Hadza, 'genus', rescale=T)
#' plotFunctions(Hadza, 'COG')
#'
"Hadza"

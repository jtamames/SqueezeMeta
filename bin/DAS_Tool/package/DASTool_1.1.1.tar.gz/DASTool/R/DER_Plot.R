#
# DAS Tool for genome-resolved metagenomics
# by Christian MK Sieber (csieber@lbl.gov)
#

DER_Plot <- function(result_list,filename){

  options(warn=-1)

  # result_list <- pretty_tables

  methods <- names(result_list)
  positions <- methods

  for(i in 1:length(result_list)){
    result_list[[i]]$Method <- methods[i]
  }
  result_table <- do.call(rbind.data.frame, result_list)


  tmp_wide <- result_table[,.(`>90%` = sum(SCG_completeness>90 & SCG_redundancy<5),
                    `>80%` = sum(SCG_completeness>80 & SCG_completeness<=90 & SCG_redundancy<5),
                    `>70%` = sum(SCG_completeness>70 & SCG_completeness<=80 & SCG_redundancy<5),
                    `>60%` = sum(SCG_completeness>60 & SCG_completeness<=70 & SCG_redundancy<5)),by=.(Method)]


  plot_table <- melt(tmp_wide,id.vars = 'Method', measure.vars = c('>90%','>80%','>70%', '>60%'), value.name = 'Bins',variable.name =  'SCG_completeness')
  plot_table$title <- 'High quality bins (< 5% SCG redundancy)'

  #compensate random changes in ggplot2 package...
  if(packageVersion("ggplot2")>=numeric_version("2.2.0")){
    plot_table$SCG_completeness <- factor(plot_table$SCG_completeness,levels = rev(c('>90%','>80%','>70%', '>60%')))
    colors <- rev(c("#08306B","#1664AB","#4A97C9","#93C4DE"))
  }else{
    plot_table$SCG_completeness <- factor(plot_table$SCG_completeness,levels = c('>90%','>80%','>70%', '>60%'))
    colors <- c("#08306B","#1664AB","#4A97C9","#93C4DE")
  }

  ggplot(plot_table, aes(Method, Bins, fill=SCG_completeness)) + geom_bar(stat="identity", position="stack")  +
    facet_grid( ~ title)  + theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
    scale_fill_manual(values = colors) +  scale_x_discrete(limits = positions)
  ggsave(paste(filename,'_DASTool_hqBins.pdf',sep=''),width = 16,height=10)


  #violin+jitter
  stats2 <- data.frame()
  # my_colors <- c("#08306B","#084A92","#1664AB","#2E7EBB","#4A97C9","#6BAED6","#93C4DE","#B5D4E9","#CFE1F2","#E3EEF8")

  plot_table2 <- result_table[ result_table$binScore > 0.25,]
  plot_table2$title <- 'Score distribution of bins (BinScore > 0.25)'
  g<-ggplot(plot_table2, aes(x=Method, y=binScore))
  g+geom_violin(alpha=0.5, color="gray")+geom_jitter(alpha=1.0, aes(color=Method),position = position_jitter(width = 0.1)) + scale_x_discrete(limits = positions) + facet_grid( ~ title) + theme(axis.text.x = element_text(angle = 45, hjust = 1))

  ggsave(paste(filename,'_DASTool_scores.pdf',sep=''),width = 16,height=10)
}

